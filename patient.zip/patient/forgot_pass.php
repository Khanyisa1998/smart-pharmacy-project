<?php 
  include"../connector.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Smart Pharmacy | Patient</title>
  <!-- base:css -->
  <link rel="stylesheet" href="vendors/typicons/typicons.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
  <style>
      .error{
        color: red;
        text-align: center;
        justify-content: center;
        justify-items: center;
        justify-self:center ;
      }
    </style>
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper" style="background-color: grey;">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <div class="brand-logo" style="justify-content:center;text-align: center;align-content: center;">
                <h6>Smart Pharmacy | Patient Password Reset</h6>
              </div>
              <h4>Hello! let's get started</h4>
              <h6 class="font-weight-light">Change your password.</h6>
              <?php
                  $emailErr = $err = $errpwd=$ercpwd=$cpwd=$err ="";
                  $email = $pwd ="";
                  $Temail = $Tpwd =$Tcpwd =false;
                
                    
                if (isset($_POST['login'])) {

                  
                  //email
                  if (empty($_POST["email"])) {
                    $emailErr = "Email is required";
                    $Temail=false;
                  } else {
                    $email = test_input($_POST["email"],$conn);
                    $Temail=true;
                   
                        $query="SELECT * FROM patient WHERE email_address='$email'";
                        $result=mysqli_query($conn,$query);
                         if(!$result){

                          die("db access failed ".mysqli_error());
                        }
                          //get the number of rows of the executed query  
                        $rows=mysqli_num_rows($result);
                                    
                        if($rows==0){
                            $emailErr ="Email not registered in our system";
                            $Temail=false;
                        }
                    
                  }
                   

                   
                   //2nd password 
                 if (empty($_POST["pwd"])) {
                    $errpwd = "Password is required";
                    $Tpwd=false;
                  } else {

                       $pwd = test_input($_POST["pwd"],$conn);
                       $Tpwd=true;
                       if (strlen($pwd)<6) {
                        // code...
                        $errpwd="Password must contain atleast 6 charecters or more.";
                      }
                       
                    }

                    if (empty($_POST['cpwd'])) {
                        // code...
                      $err="Confirm password is required.";
                      $Tcpwd=false;
                    }else{
                      $cpwd=test_input($_POST["cpwd"],$conn);;
                      $Tcpwd=true;
                      if ($pwd!=$cpwd) {
                        // code...
                        $err="Passwords do not match.";
                        $Tcpwd=false;
                      }
                    }

                     if ($Tpwd && $Temail && $Tcpwd) {
                         
                        $hashp=password_hash($cpwd,PASSWORD_DEFAULT);
                        $query="UPDATE patient SET password='$hashp' WHERE email_address='$email'";
                        $result=mysqli_query($conn,$query);

                        if(!$result)
                        {
                          $err="unable to connect to database ".mysqli_error($conn);
                        }else{
                            
                          
                        echo '<script type="text/javascript">alert("You Succesfully changed your password."); window.location = "login.php";</script>';
                            }
                        }
                      
            }
              ?>

              <form class="pt-3" action="" method="post">
                <div class="form-group">
                  <input type="email" class="form-control form-control-lg" name="email" placeholder="Email" value="<?php echo $email;?>" style="border-color: black;">
                  <span class="error"><p><?php echo $emailErr;?></p></span>
                </div>
               
                <div class="form-group">
                  <input type="password" class="form-control form-control-lg" name="pwd" placeholder="Enter Password" style="border-color: black;">
                  <span class="error"><p><?php echo $errpwd;?></p></span>
                </div>
                <div class="form-group">
                  <input type="password" class="form-control form-control-lg" name="cpwd" placeholder="Confirm Password" style="border-color: black;">
                  <span class="error"><p><?php echo $err;?></p></span>
                </div>
                <div class="mt-3">
                  <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" name="login">Change Password</a>
                </div>
                <div class="my-2 d-flex justify-content-between align-items-center">
                  <!-- <div class="form-check">
                    <label class="form-check-label text-muted">
                      <input type="checkbox" class="form-check-input">
                      Keep me signed in
                    </label>
                  </div> -->
                  <a href="login.php" class="auth-link text-black">Remember password?</a>
                </div>
                
                <div class="text-center mt-4 font-weight-light">
                  Don't have an account? <a href="register.php" class="text-primary">Create</a>
                </div>
                <hr>
                <div class="mb-2">
                  <a href="../index.php" class="btn btn-block btn-facebook auth-form-btn">
                    Ruturn To Home Page
                  </a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- base:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
</body>

</html>
