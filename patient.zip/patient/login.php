<?php 
  include"../connector.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Smart Pharmacy | Patient</title>
  <!-- base:css -->
  <link rel="stylesheet" href="vendors/typicons/typicons.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
  <style>
      .error{
        color: red;
        text-align: center;
        justify-content: center;
        justify-items: center;
        justify-self:center ;
      }
    </style>
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper" style="background-color: grey;">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <div class="brand-logo" style="justify-content:center;text-align: center;align-content: center;">
                <h6>Smart Pharmacy | Patient Login</h6>
              </div>
              <h4>Hello! let's get started</h4>
              <h6 class="font-weight-light">log in to continue.</h6>
              <?php
                $eremail = $err = $erpwd ="";
                $email = $pwd ="";
                $Temail = $Tpwd =false;
                  
              if (isset($_POST['login'])) {

                
                //email
                if (empty($_POST["email"])) {
                  $eremail = "Email is required";
                  $Temail=false;
                } else {
                  $email = test_input($_POST["email"],$conn);
                  $Temail=true;
                  // check if e-mail address is well-formed
                  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $eremail = "Invalid email format";
                    $Temail=false; 
                  }else{
                      $query="SELECT * FROM patient WHERE email_address='$email'";
                      $result=mysqli_query($conn,$query);
                       if(!$result){

                        die("db access failed ".mysqli_error());
                      }
                        //get the number of rows of the executed query  
                      $rows=mysqli_num_rows($result);
                                  
                if($rows==0){
                          $eremail ="User not registered on our system";
                          $Temail=false;
                      }
                  }
                }
                 

                 
                 //2nd password 
               if (empty($_POST["pwd"])) {
                  $erpwd = "Password is required";
                  $Tpwd=false;
                } else {

                     $pwd = test_input($_POST["pwd"],$conn);
                     $Tpwd=true;
                     
                  }
                   if ($Tpwd && $Temail) {
                       
                     
                      $query="SELECT * FROM patient WHERE email_address='$email'";
                      $result=mysqli_query($conn,$query);

                      if(!$result)
                      {
                        $erpwd="unable to connect to database";
                         mysqli_error($conn);
                      }else{
                          $rows=mysqli_num_rows($result);
                          if($rows<1)
                          {
                              $erpwd="username or password doesnt exsist";
                      
                          }else{
                                  

                                  while ($rows=mysqli_fetch_assoc($result)) 
                                      {
                                          $cpwd=$rows['password'];
                                          
                                          //!password_verify('$passwd',$cpwd) !hash_equals('$passwd',$cpwd)
                          

                                          if (!password_verify($pwd,$cpwd)) {
                                              $erpwd="incorrect username or password";
                                          }else{
                                            session_start();
                                              $_SESSION['email']=$rows['email_address'];
                                              $_SESSION['id']=$rows['patientID'];
                                              $_SESSION['name']=$rows['firstname'];
                                              $_SESSION['surname']=$rows['lastname'];
                                              $_SESSION['address']=$rows['res_address'];
                                              $_SESSION['cell']=$rows['cell_number'];
                                              $_SESSION['city']=$rows['city'];

                                              $_SESSION['id_number']=$rows['id_number'];
                                              $_SESSION['postal_code']=$rows['postal_code'];
                                              //$_SESSION['city']=$rows['city'];
                                              

                                                echo '<script> window.location = "index.php";</script>';
                                              
                                              
                                            }

                                              
                                              
                                              
                                                              
                                          }


                                  
                                      }

                              }
                          }
                        
                      }

              ?>

              <form class="pt-3" action="" method="post">
                <div class="form-group">
                  <input type="email" class="form-control form-control-lg" name="email" placeholder="Email" value="<?php echo $email;?>" style="border-color: black;">
                  <span class="error"><p><?php echo $eremail;?></p></span>
                </div>
               
                <div class="form-group">
                  <input type="password" class="form-control form-control-lg" name="pwd" placeholder="Enter Password" style="border-color: black;">
                  <span class="error"><p><?php echo $erpwd;?></p></span>
                </div>
                <div class="mt-3">
                  <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" name="login">SIGN IN</a>
                </div>
                <div class="my-2 d-flex justify-content-between align-items-center">
                  <!-- <div class="form-check">
                    <label class="form-check-label text-muted">
                      <input type="checkbox" class="form-check-input">
                      Keep me signed in
                    </label>
                  </div> -->
                  <a href="forgot_pass.php" class="auth-link text-black">Forgot password?</a>
                </div>
                
                <div class="text-center mt-4 font-weight-light">
                  Don't have an account? <a href="register.php" class="text-primary">Create</a>
                </div>
                <hr>
                <div class="mb-2">
                  <a href="../index.php" class="btn btn-block btn-facebook auth-form-btn">
                    Ruturn To Home Page
                  </a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- base:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
</body>

</html>
