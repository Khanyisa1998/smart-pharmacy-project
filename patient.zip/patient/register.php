<?php 
  include"../connector.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Smart Pharmacy | Patient</title>
  <!-- base:css -->
  <link rel="stylesheet" href="vendors/typicons/typicons.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />

  <style>
      .error{
        color: red;
        text-align: center;
        justify-content: center;
        justify-items: center;
        justify-self:center ;
      }
    
    .loader {
      border: 16px solid #f3f3f3;
      border-radius: 50%;
      border-top: 16px solid #3498db;
      width: 120px;
      height: 120px;
      -webkit-animation: spin 2s linear infinite; /* Safari */
      animation: spin 2s linear infinite;
    }

    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  </style>
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth px-0" style="background-color: grey;">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <div class="brand-logo" style="justify-content:center;text-align: center;align-content: center;">
                <h6>Smart Pharmacy | Patient Registration</h6>
              </div>
              <h4>New here?</h4>
              <h6 class="font-weight-light">Signing up is easy. It only takes a few steps</h6>
              <?php
               $pname=$psurname=$pdob=$pemail=$pcellno=$idno=$pwd=$cpwd=$hashp=$paddress=$pcity=$pcode="";
                
                $err=$ername=$ersurname=$erdob=$eremail=$ereidno=$ercellno=$erpwd=$ercpwd=$erpaddress=$erpcity=$erpcode="";

                  $Tname=$Tsurname=$Tdob=$Temail=$Tcellno=$Tidno=$Tpwd=$Tcpwd=$Tpaddress=$Tpcity=$Tpcode=false;
                    

                  if (isset($_POST['register'])) {
                     
                  if (empty($_POST["pname"])) {
                    $ername = "Firstname is required";
                    $Tname=false;
                  } else {
                    $pname = test_input($_POST["pname"],$conn);
                    $Tname=true;
                    // check if name only contains letters and whitespace
                    if (!preg_match("/^[a-zA-Z ]*$/",$pname)) {
                      $ername = "Only letters and white space allowed";
                      $Tname=false; 
                    }else{
                        if(strlen($pname)<2){
                            $ername = "Fisrtname is short";
                            $Tname=false;

                        }
                    }
                  }

                   if (empty($_POST["psurname"])) {
                    $ersurname = "Lastname is required";
                    $Tsurname=false;
                  } else {
                    $psurname = test_input($_POST["psurname"],$conn);
                    $Tsurname=true;
                    // check if name only contains letters and whitespace
                    if (!preg_match("/^[a-zA-Z ]*$/",$psurname)) {
                      $ersurname = "Only letters and white space allowed";
                      $Tsurname=false; 
                    }else{
                        if(strlen($psurname)<2){
                            $ersurname = "Lastname is short";
                            $Tsurname=false;

                        }
                    }
                  }
                  
                  
                 if (empty($_POST["pemail"])) {
                    $eremail= "Email is required";
                    $Temail=false;
                  } else {
                    $pemail = test_input($_POST["pemail"],$conn);
                    $Temail=true;
                    // check if e-mail address is well-formed
                    if (!filter_var($pemail, FILTER_VALIDATE_EMAIL)) {
                      $eremail= "Invalid email format";
                      $Temail=false; 
                    }else{

                        $query="SELECT * FROM patient WHERE email_address='$pemail'";
                        $result=mysqli_query($conn,$query);
                         if(!$result){

                          die("db access failed ".mysqli_error());
                        }
                          //get the number of rows of the executed query  
                        $rows=mysqli_num_rows($result);
                                    
                  if($rows>0){
                            $eremail ="Email already registered in our system";
                            $Temail=false;
                        }
                    }
                  
                   }

                   if (empty($_POST["idno"])) {
                      $ereidno = "ID number is required";
                      $Tidno=false;
                    } else {
                      $idno = test_input($_POST["idno"],$conn);
                      $Tidno=true;
                      // check if name only contains letters and whitespace
                      if (!preg_match("/^[0-9]*$/",$idno)) {
                        $ereidno = "Only digits allowed"; 
                        $Tidno=false;
                      }else{
                          if(strlen($idno)!=13){
                              $ereidno = "ID number must be 13 digits";
                              $Tidno=false;
                            }else{


                          $query="SELECT * FROM patient WHERE id_number='$idno'";
                          $result=mysqli_query($conn,$query);
                           if(!$result){

                            die("db access failed ".mysqli_error($conn));
                          }
                            //get the number of rows of the executed query  
                          $rows=mysqli_num_rows($result);
                                      
                        if($rows>0){
                              $ereidno ="ID number already registered";
                              $Tidno=false;
                          }else{

                            if ($idno=="0000000000000") {
                              # code...
                              $ereidno = "Invalid ID Number";
                              $Tidno=false;
                            }else{
                              if (substr($idno, 6,1)>=5) {
                                # code...
                                //$error_idno = "gender= Male";
                              }else{
                               //$error_idno = "gender= Female";
                              }

                              if (substr($idno, 10,1)==0) {
                                # code...
                                //$error_idno .= "<br>Natioanality: SA Citizen";
                              }elseif (substr($idno, 10,1)==1) {
                                # code...
                                
                              }else{
                                $ereidno = "The 11th digit must either be 0 or 1";
                                $Tidno=false;
                              }

                              if (substr($idno, 0,2)>20) {
                                # code...
                                $date= date("Y");
                                $dob="19".substr($idno, 0,2);
                                if ($date-$dob>17) {
                                  
                                }else{
                                $ereidno = "Household owner has to be 18 years old or older";
                                $Tidno=false;
                                }

                              }else{
                                 $date= date("Y");
                                  $dob="20".substr($idno, 0,2);
                               //$error_idno = $date." - 20".substr($idno, 0,2);
                               if ($date-$dob>17) {
                                  
                                }else{
                                $ereidno = "Sorry user has to be 18 years old or older";
                                $Tidno=false;
                                }
                              }

                              if (substr($idno, 2,2)>12) {
                                # code...
                                $ereidno = "Sorry there are 12 months in a year";
                                $Tidno=false;
                              }else{
                                //echo substr($idno, 0,2)." ".substr($idno, 2,2)." ".substr($idno, 4,2);
                                if (substr($idno, 4,2)>31) {
                                  # code...
                                  $ereidno = "Sorry a month may consist of 29 to 31 days";
                                  $Tidno=false;
                                }
                               
                              }
                              if (substr($idno, 2,2)==2||substr($idno, 2,2)==02||substr($idno, 2,2)=="02") {
                                # code...
                                if (substr($idno, 4,2)>29) {
                                  # code...
                                  $ereidno = "Sorry February may consist of 29 days max";
                                  $Tidno=false;
                                }
                                
                              }else{
                                //echo substr($idno, 0,2)." ".substr($idno, 2,2)." ".substr($idno, 4,2);
                                if (substr($idno, 4,2)>31) {
                                  # code...
                                  $ereidno = "Sorry a months may consist of 29 to 31 days";
                                  $Tidno=false;
                                }
                               
                              }
                            }
                          }
                    

                          }
                      }
                    }

                   if (empty($_POST["pcode"])) {
                      $erpcode = "Postal Code is required";
                      $Tpcode=false;
                    } else {
                      $pcode = test_input($_POST["pcode"],$conn);
                      $Tpcode=true;
                      
                    }

                  if (empty($_POST["paddress"])) {
                    $erpaddress = "Address is required";
                    $Tpaddress=false;
                  } else {
                    $paddress = test_input($_POST["paddress"],$conn);
                    $Tpaddress=true;
                    
                  }
    
                  if (empty($_POST["pcity"])) {
                    $erpcity = "City is required";
                    $Tpcity=false;
                  } else {
                    $pcity = test_input($_POST["pcity"],$conn);
                    $Tpcity=true;
                    
                  }

                   if (empty($_POST["pcellno"])) {
                  $ercellno = "Phone number is required";
                  $Tcellno=false;
                } else {
                  $pcellno = test_input($_POST["pcellno"],$conn);
                  $Tcellno=true;
                  // check if name only contains letters and whitespace
                  if (!preg_match("/^[0-9]*$/",$pcellno)) {
                    $ercellno = "Only numbers allowed"; 
                    $Tcellno=false;
                  }else{
                      if(strlen($pcellno)!=10){
                          $ercellno = "Phone number must be 10 digits";
                          $Tcellno=false;

                      }

                      }
                  }
    
    
                    //1st password
                  if (empty($_POST["pwd"])) {
                    $erpwd = "Password is required";
                    $Tpwd=false;
                  } else {
                    $pwd = test_input($_POST["pwd"],$conn);
                    $Tpwd=true;

                        if(strlen($pwd)<8){
                            $erpwd = "password must have at least 8 characters or digits";
                            $Tpwd=false;
                            
                        }
                    }
                    
                  
                    
                   //2nd password 
                 if (empty($_POST["cpwd"])) {
                    $ercpwd = "Password confirm is required";
                    $Tcpwd=false;
                  } else {
                        $cpwd = test_input($_POST["cpwd"],$conn);
                        $hashp=password_hash($pwd,PASSWORD_DEFAULT);
                        $Tcpwd=true;

                        if ($pwd!=$cpwd){
                                $ercpwd = "Password do match";
                                $Tcpwd=false;
                        }
                        
                  }
                 
                   if ($Tname&&$Tsurname&&$Temail&&$Tcellno&&$Tidno&&$Tpaddress&&$Tpcity&&$Tpcode&&$Tpwd&&$Tcpwd&&$hashp) {
                              
                        //echo $staffno." ".;

                      $sql="INSERT INTO `patient`(`firstname`, `lastname`, `id_number`, `email_address`, `cell_number`, `res_address`, `city`, `postal_code`, `password`) VALUES ('$pname','$psurname','$idno','$pemail','$pcellno','$paddress','$pcity','$pcode','$hashp')";

                      if(mysqli_query($conn,$sql))
                          {
                               
                              echo '<script type="text/javascript">alert("You registeredS Succesfully."); window.location = "login.php";</script>';
                              
                          }else{echo("<h3>unsuccessfully not registered </h3>".mysqli_error($conn)); }
                                        
                          }
                }


            
                ?>
              <form class="pt-3" action="" method="post">
                <div class="form-group">
                  <label>First Name</label>
                  <input type="text" class="form-control form-control-lg" name="pname" placeholder="Enter Fisrt Name" value="<?php echo $pname;?>" style="border-color: black;">
                  <span class="error"><p><?php echo $ername;?></p></span>
                </div>
                <div class="form-group">
                  <label>Last Name</label>
                  <input type="text" class="form-control form-control-lg" name="psurname" placeholder="Enter Last Name" value="<?php echo $psurname;?>" style="border-color: black;">
                  <span class="error"><p><?php echo $ersurname;?></p></span>
                </div>
                <div class="form-group">
                  <label>ID Number</label>
                  <input type="text" class="form-control form-control-lg" name="idno" placeholder="Enter ID Number" value="<?php echo $idno;?>" style="border-color: black;">
                  <span class="error"><p><?php echo $ereidno;?></p></span>
                </div>
                <div class="form-group">
                  <label>Cell Number</label>
                  <input type="text" class="form-control form-control-lg" name="pcellno" placeholder="Enter Cell Number" value="<?php echo $pcellno;?>" style="border-color: black;">
                  <span class="error"><p><?php echo $ercellno;?></p></span>
                </div>
                <div class="form-group">
                  <label>Email</label>
                  <input type="email" class="form-control form-control-lg" name="pemail" placeholder="Email" value="<?php echo $pemail;?>" style="border-color: black;">
                  <span class="error"><p><?php echo $eremail;?></p></span>
                </div>
                <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDWsm32O9PMhNQgEDCCO7EZvgAjYPKEQHs&v=3.exp&sensor=false&libraries=places"></script>

                <div class="form-group">
                  <label>Address</label>
                  <input type="text" class="form-control form-control-lg" name="paddress" placeholder="Enter Address" value="<?php echo $paddress;?>" style="border-color: black;" id="searchTextField" onkeyup="show_load(this);">
                  <span class="error"><p><?php echo $erpaddress;?></p></span>
                </div>
                <div class="loader" id="load2"></div>
                
                <div class="form-group">
                  <input type="text" class="form-control form-control-lg" name="pcity"
                  id="pcity" placeholder="City" value="<?php echo $pcity;?>" style="border-color: black;" readonly>
                  <span class="error"><p><?php echo $erpcity;?></p></span>
                </div>
                <div class="form-group">
                  <input type="email" class="form-control form-control-lg" name="pcode"  id="pcode" placeholder="Postal Code" value="<?php echo $pcode;?>" style="border-color: black;" readonly>
                  <span class="error"><p><?php echo $erpcode;?></p></span>
                </div>
               
                <div class="form-group">
                  <input type="password" class="form-control form-control-lg" name="pwd" placeholder="Enter Password" style="border-color: black;">
                  <span class="error"><p><?php echo $erpwd;?></p></span>
                </div>
                <div class="form-group">
                  <input type="password" class="form-control form-control-lg" name="cpwd" placeholder="Confirm Password" style="border-color: black;">
                  <span class="error"><p><?php echo $ercpwd;?></p></span>
                </div>
                <!-- <div class="mb-4">
                  <div class="form-check">
                    <label class="form-check-label text-muted">
                      <input type="checkbox" class="form-check-input" required>
                      I agree to all Terms & Conditions
                    </label>
                  </div>
                </div> -->
                <div class="mt-3">
                  <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" name="register" id="register">SIGN UP</button>
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Already have an account? <a href="login.php" class="text-primary">Login</a>
                </div>
                <hr>
                <div class="mb-2">
                  <a href="../index.php" class="btn btn-block btn-facebook auth-form-btn">
                    Ruturn To Home Page
                  </a>
                </div>
              </form>
               <!-- Initialization -->
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
                <script>
                  document.getElementById("load2").style.display="none";
                function show_load(input) {
                  // body...
                  if (input.value==="") {
                      document.getElementById("load2").style.display="none";
                      document.getElementById("pcity").style.display="block";
                      document.getElementById("pcode").style.display="block";
                      document.getElementById("register").style.display="block";
                    }else{
                      document.getElementById("load2").style.display="block";
                      document.getElementById("pcity").style.display="none";
                      document.getElementById("pcode").style.display="none";
                      document.getElementById("register").style.display="none";
                    }
                }
                  let places, input, address, city;
                  google.maps.event.addDomListener(window, "load", function () {
                    

                    var places = new google.maps.places.Autocomplete(
                      document.getElementById("searchTextField")
                    );
                    google.maps.event.addListener(places, "place_changed", function () {
                      var place = places.getPlace();
                      //console.log(place)
                      var address = place.formatted_address;
                      var latitude = place.geometry.location.lat();
                      var longitude = place.geometry.location.lng();
                      var latlng = new google.maps.LatLng(latitude, longitude);
                      var geocoder = (geocoder = new google.maps.Geocoder());
                      geocoder.geocode({ latLng: latlng }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                          if (results[0]) {
                            var address = results[0].formatted_address;
                            var pin =
                              results[0].address_components[
                                results[0].address_components.length - 1
                              ].long_name;
                            var country =
                              results[0].address_components[
                                results[0].address_components.length - 2
                              ].long_name;
                            var state =
                              results[0].address_components[
                                results[0].address_components.length - 3
                              ].long_name;
                            var city =
                              results[0].address_components[
                                results[0].address_components.length - 4
                              ].long_name;
                             /* console.log(country)
                              console.log(state)
                              console.log(city)
                              console.log(pin)
                             let row = `
                             
                             <tr id="country">
                        <td>${country}</td>
                        <td>${state}</td>
                         <td>${city}</td>
                         <td>${pin}</td>
                      </tr>
                     
                             
                             `
                             $("#body").append(row);*/
                             document.getElementById("pcity").value=city;
                             document.getElementById("pcode").value=pin;

                             document.getElementById("pcity").style.display="block";
                             document.getElementById("pcode").style.display="block";
                             document.getElementById("load2").style.display="none";
                             document.getElementById("register").style.display="block";
                          }
                        }
                      });
                    });
                  });
                </script>
                <!-- end Initialization -->
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- base:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
</body>

</html>
