<?php
include 'connector.php';
$pid=$_GET['pid'];

$sql="DELETE FROM `patient` WHERE  `patientID`='$pid'";
if (mysqli_query($conn,$sql)) {
  # code...
echo '<script type="text/javascript">alert("Account deleted successfully");</script>';
echo '<script>window.location ="logout.php"</script>';
}else{
  echo "Error!. ".mysqli_error($conn);
}

?>